import java.util.Scanner;
public class triangle
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
    int height;
    int base;
    double area;
    System.out.println("What is the height of your triangle ");
    height = in.nextInt();
    System.out.print("What is the base of the triangle ");
    base = in.nextInt();
    area = (height * base)/2;
    System.out.println("the area of your triangle is " + area);
}
}
   