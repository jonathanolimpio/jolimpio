import java.util.Scanner; 
public class MyClass {
static Scanner in = new Scanner(System.in); 
public static void main() {
int n1;
double avg;
System.out.print("Enter a number ");
n1 = in.nextInt();
System.out.println("The number you entered was " + n1);
}
}

