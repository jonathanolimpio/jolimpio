import java.util.Scanner;

public class rectangle
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
    int length;
    int width;
    double area;
    double perimeter;
    System.out.print("what is the length of the rectangle ");
    length = in.nextInt();
    System.out.print("What is the width of the rectangle ");
    width = in.nextInt();
    area = length*width;
    perimeter = length + length + width + width;
    System.out.println("The area and the perimeter is " + area  + perimeter);
}
}

