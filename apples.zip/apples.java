import java.util.Scanner;
import java.io.*;

public class apples
{
static Scanner in = new Scanner(System.in);     
 
public static void main() {
 int apples;
  double price;
  double total;
  System.out.println("How many apples are you buying");
  apples = in.nextInt();
  System.out.print("How much is each apple");
  price = in.nextDouble();
  total=price*apples;
  System.out.println("The total is "+total);
}
}