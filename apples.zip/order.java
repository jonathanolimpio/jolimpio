import java.util.Scanner;
import java.io.*;

public class order
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
double a = 4, b = 6, c = 8;
double d= 10;
System.out.println(a+b/c+d);}}
