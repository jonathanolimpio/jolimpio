import java.util.Scanner;
public class discount
{
static Scanner in = new Scanner(System.in);     
  
public static void main() { 
    int price;
    double d;
    double off;
    double sp;
    System.out.println(" What is the price of the object(s) ");
    price = in.nextInt();
    System.out.print("What is the discount you are getting on this object ");
    d = in.nextDouble();
    off = price * d;
    System.out.print(" This is the amount you get off " + off);
    sp = price- off;
    System.out.println("  The final price is " +sp);
}
}
    
 