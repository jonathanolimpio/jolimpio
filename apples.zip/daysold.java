import java.util.Scanner;

public class daysold
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
    int age;
    double days;
    System.out.print("How old are you");
    age = in.nextInt();
    days = age*365.25;
    System.out.println("You are this many days old "+days);
}
}
    
  
