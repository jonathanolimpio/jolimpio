import java.util.Scanner;
public class weeks
{
static Scanner in = new Scanner(System.in);     
  
public static void main() { 
    int ys;
    double ws;
    System.out.println(" What is your yearly salary ");
    ys = in.nextInt();
    ws = ys/52;
    System.out.println("Your weekly salary is " + ws);
}
}
    
 