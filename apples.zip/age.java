
import java.util.Scanner;

public class age
{
static Scanner in = new Scanner(System.in);     
  
public static void main() 
{int age;
System.out.print("Enter your age ");
age = in.nextInt();
 if (age >= 40)
 System.out.println("You are old");
else if (age==35)
 System.out.println("you are middle aged ");
else if (age <29)
 System.out.println("You are young");
}
}
