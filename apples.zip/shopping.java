import java.util.Scanner;

public class shopping
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
    int p1;
    int p2;
    int p3;
    double total;
    double tax;
    System.out.print("what was the cost of the first item ");
    p1 = in.nextInt();
    System.out.print("What is the cost of the second product ");
    p2 = in.nextInt();
    System.out.print("What is the cost of the final product ");
    p3 = in.nextInt();
    tax = (p1+p2+p3)*.06;
    total = tax + p1 + p2 +p3;
    System.out.println("the total cost is "+total);
}
}
    
    

