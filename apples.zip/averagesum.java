
import java.util.Scanner; 
public class averagesum {

static Scanner in = new Scanner(System.in); 
public static void main() 
{
    int n1;
    int n2;
    int n3;
    int n4;
    int n5;
    double average;
    double sum;
    System.out.print("What is your first number ");
    n1 = in.nextInt();
    System.out.print("what is your second number ");
    n2 = in.nextInt();
    System.out.print("What is your third number ");
    n3 = in.nextInt();
    System.out.print("What is your fourth number ");
    n4 = in.nextInt();
    System.out.print("What is your fifth number ");
    n5 = in.nextInt();
    average = (n1 + n2 + n3 + n4 + n5)/5;
    System.out.println("the average is "+average);
    sum = n1 + n2 + n3 + n4 + n5;
    System.out.println("the sum is "+ sum);
}
}
    
   

