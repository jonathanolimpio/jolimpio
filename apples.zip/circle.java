import java.util.Scanner;
public class circle
{
static Scanner in = new Scanner(System.in);     
  
public static void main() { 
    int radius;
    double area;
    double C;
    System.out.println(" enter the radius of the circle ");
    radius = in.nextInt();
    area = 3.14 *radius*radius;
    System.out.print("the area is " +area);
    C = 2*3.14*radius;
    System.out.println(" The circumference is " + C);
}
}
  