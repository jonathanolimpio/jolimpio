import java.util.Scanner;
import java.io.*;

public class Movies
{
static Scanner in = new Scanner(System.in);     
 
public static void main() {

    int kids;
    int adults;
    double total;
    System.out.println("How many adults are going to the movies ");
    adults = in.nextInt();
    System.out.print("how many kids are going to the movies ");
    kids = in.nextInt();
    total = (adults*8.50)+(kids*5.00);
    System.out.println(" the total cost is "+total);
}
}
    
  
    
     
