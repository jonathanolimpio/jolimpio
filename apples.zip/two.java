
import java.util.Scanner;
import java.io.*;

public class two
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
double n1, n2 , n3 , n4;
double avg;
System.out.print("Enter a number ");
n1 = in.nextInt();
System.out.print("Enter the second number ");
n2 = in.nextInt();
System.out.print("Enter the third number ");
n3 = in.nextInt();
System.out.print("Enter the fourth number ");
n4 = in.nextInt();
avg = (n1 +n2+n3+n4)/4.0;
System.out.println("Average is " + avg);
}
}
