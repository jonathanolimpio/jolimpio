import java.util.Scanner;

public class height
{
static Scanner in = new Scanner(System.in);     
  
public static void main() {
    int feet;
    int inches;
    double total;
    System.out.print("How many feet are you");
    feet = in.nextInt();
    System.out.print("How many inches out of the feet are you");
    inches = in.nextInt();
    total = (feet*12)+inches;
    System.out.println("You are "+total);
}
}


