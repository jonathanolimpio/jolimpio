import java.util.Scanner;
import java.io.*;

public class hours
{
static Scanner in = new Scanner(System.in);     
 
public static void main() {
    int hours;
    int salary;
    double total;
    System.out.println("How many hours do you work a week");
    hours = in.nextInt();
    System.out.println("how much do you make an hour");
    salary = in.nextInt();
    total = hours*salary;
    System.out.println(" The amount of money you make per week is " + total);
}
}
